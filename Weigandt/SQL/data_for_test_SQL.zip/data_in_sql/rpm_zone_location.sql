insert into rpm_zone_location (ZONE_ID, LOCATION)
values (1, 2002);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (1, 2006);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (1, 2008);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (1, 2011);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (1, 2015);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (1, 2016);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (1, 2017);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (1, 2019);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (1, 2020);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (1, 2022);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (1, 2023);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (1, 2025);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (1, 2030);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (1, 2031);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (1, 2038);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (1, 2039);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (3, 2012);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (3, 2853);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (3, 5869);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3492);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3494);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3500);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3501);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3502);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3503);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3504);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3505);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3506);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3507);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3508);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3510);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3512);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3513);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3514);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3515);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3516);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3517);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3548);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3549);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3553);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3559);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3562);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3566);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3572);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 3689);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 4271);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 4360);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 4449);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 4578);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (11, 3511);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (11, 3550);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (11, 4384);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (11, 4406);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (11, 4475);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (3, 6536);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 2007);

insert into rpm_zone_location (ZONE_ID, LOCATION)
values (2, 2040);

COMMIT;
