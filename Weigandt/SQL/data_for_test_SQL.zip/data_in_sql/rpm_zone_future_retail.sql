
insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942489, '050233719', 2, to_date('05-01-2018', 'dd-mm-yyyy'), 16.0000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942290, '050234494', 2, to_date('17-12-2017', 'dd-mm-yyyy'), 0.4500, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942119, '050234494', 2, to_date('02-01-2018', 'dd-mm-yyyy'), 0.3500, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108453, '050234845', 3, to_date('21-11-2017', 'dd-mm-yyyy'), 12.0000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942141, '050234056', 2, to_date('04-01-2018', 'dd-mm-yyyy'), 13.8900, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108616, '050374500', 2, to_date('03-01-2018', 'dd-mm-yyyy'), 4.5000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108613, '050245008', 11, to_date('31-07-2013', 'dd-mm-yyyy'), 4.5400, 'EUR', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108554, '050244977', 2, to_date('03-01-2018', 'dd-mm-yyyy'), 6.5400, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108525, '050244977', 1, to_date('03-01-2018', 'dd-mm-yyyy'), 6.5400, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108494, '050235631', 1, to_date('27-12-2017', 'dd-mm-yyyy'), 12.0900, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108491, '050235631', 2, to_date('27-12-2017', 'dd-mm-yyyy'), 12.0900, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108696, '050374500', 1, to_date('03-01-2018', 'dd-mm-yyyy'), 4.3400, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942486, '050233719', 1, to_date('05-02-2014', 'dd-mm-yyyy'), 11.0000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942488, '050233719', 2, to_date('05-02-2014', 'dd-mm-yyyy'), 15.7900, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942499, '050233725', 1, to_date('05-02-2014', 'dd-mm-yyyy'), 12.5000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942501, '050233725', 2, to_date('05-02-2014', 'dd-mm-yyyy'), 13.1300, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942504, '050233760', 1, to_date('15-01-2014', 'dd-mm-yyyy'), 10.0000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942507, '050233760', 2, to_date('15-01-2014', 'dd-mm-yyyy'), 10.5000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942511, '050234056', 1, to_date('27-05-2013', 'dd-mm-yyyy'), 10.0000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942512, '050234056', 2, to_date('27-05-2013', 'dd-mm-yyyy'), 15.8900, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942517, '050234062', 1, to_date('15-01-2014', 'dd-mm-yyyy'), 12.0000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942520, '050234062', 1, to_date('21-12-2018', 'dd-mm-yyyy'), 12.0000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942898, '050234062', 1, to_date('30-12-2018', 'dd-mm-yyyy'), 12.0000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942900, '050234062', 2, to_date('15-01-2014', 'dd-mm-yyyy'), 12.6000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942903, '050234062', 2, to_date('21-12-2018', 'dd-mm-yyyy'), 11.5500, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942906, '050234062', 2, to_date('30-12-2018', 'dd-mm-yyyy'), 11.5500, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942913, '050234321', 1, to_date('25-07-2014', 'dd-mm-yyyy'), 5.5000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942915, '050234321', 2, to_date('25-07-2014', 'dd-mm-yyyy'), 5.7800, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942918, '050234494', 1, to_date('31-07-2013', 'dd-mm-yyyy'), 0.5000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942919, '050234494', 2, to_date('31-07-2013', 'dd-mm-yyyy'), 0.5000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942921, '050234822', 1, to_date('31-03-2017', 'dd-mm-yyyy'), 10.0000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (608942929, '050234822', 2, to_date('31-03-2017', 'dd-mm-yyyy'), 10.0000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (609361618, '050234845', 1, to_date('15-01-2014', 'dd-mm-yyyy'), 12.0000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108484, '050234845', 1, to_date('21-11-2017', 'dd-mm-yyyy'), 12.0000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108488, '050234845', 2, to_date('15-01-2014', 'dd-mm-yyyy'), 12.6000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108490, '050234845', 2, to_date('21-11-2017', 'dd-mm-yyyy'), 12.6000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108495, '050235631', 1, to_date('02-06-2011', 'dd-mm-yyyy'), 1.4900, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108497, '050235631', 2, to_date('02-06-2011', 'dd-mm-yyyy'), 1.5500, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108527, '050244977', 1, to_date('31-07-2013', 'dd-mm-yyyy'), 4.2700, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108550, '050244977', 2, to_date('31-07-2013', 'dd-mm-yyyy'), 4.4800, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108564, '050245008', 1, to_date('31-07-2013', 'dd-mm-yyyy'), 4.2700, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108611, '050245008', 2, to_date('31-07-2013', 'dd-mm-yyyy'), 4.4800, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108634, '050374500', 1, to_date('07-07-2017', 'dd-mm-yyyy'), 3.8900, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108646, '050374500', 2, to_date('07-07-2017', 'dd-mm-yyyy'), 4.0800, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108719, '055231996-001', 1, to_date('28-08-2013', 'dd-mm-yyyy'), 1.0000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108725, '055231996-001', 2, to_date('28-08-2013', 'dd-mm-yyyy'), 1.0000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108729, '055252602', 1, to_date('02-06-2011', 'dd-mm-yyyy'), 10.6700, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108741, '055252602', 2, to_date('02-06-2011', 'dd-mm-yyyy'), 10.6700, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108751, '067771960', 1, to_date('31-03-2017', 'dd-mm-yyyy'), 12.5000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108788, '067771960', 2, to_date('31-03-2017', 'dd-mm-yyyy'), 12.5000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108795, '082385381', 1, to_date('28-11-2017', 'dd-mm-yyyy'), 8.7500, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108816, '082385381', 2, to_date('28-11-2017', 'dd-mm-yyyy'), 8.7500, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108860, '082802992', 1, to_date('18-12-2017', 'dd-mm-yyyy'), 89.9900, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108910, '082802977', 1, to_date('18-12-2017', 'dd-mm-yyyy'), 48.0000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108919, '082803037', 2, to_date('18-12-2017', 'dd-mm-yyyy'), 42.0000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (614108925, '084785359', 2, to_date('07-12-2017', 'dd-mm-yyyy'), 16.0000, 'GBP', 'EA');

insert into rpm_zone_future_retail (ZONE_FUTURE_RETAIL_ID, ITEM, ZONE, ACTION_DATE, SELLING_RETAIL, SELLING_RETAIL_CURRENCY, SELLING_UOM)
values (617539734, '084785394', 2, to_date('07-12-2017', 'dd-mm-yyyy'), 1.5000, 'GBP', 'EA');


COMMIT;